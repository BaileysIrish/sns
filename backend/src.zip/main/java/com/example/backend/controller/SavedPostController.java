package com.example.backend.controller;
import com.example.backend.model.SavedPost;
import com.example.backend.service.SavedPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/saved-posts")
public class SavedPostController {
    @Autowired
    private SavedPostService savedPostService;

    @PostMapping("/save")
    public SavedPost savePost(@RequestBody SavedPost post) {
        System.out.println("POST 요청 수신: " + post); // 로그 추가
        return savedPostService.savePost(post);
    }

    @GetMapping("/{userId}")
    public List<SavedPost> getSavedPosts(@PathVariable String userId) {
        return savedPostService.getSavedPostsByUser(userId);
    }


    @GetMapping("/is-saved")
    public boolean isPostSaved(@RequestParam String userId, @RequestParam String content) {
        return savedPostService.isPostSaved(userId, content);
    }
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteSavedPost(@RequestParam String userId, @RequestParam String content) {
        savedPostService.deleteSavedPost(userId, content);
        return ResponseEntity.ok("저장된 게시물이 삭제되었습니다.");
    }
}

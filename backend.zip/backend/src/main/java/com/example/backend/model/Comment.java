package com.example.backend.model;

public class Comment {
}

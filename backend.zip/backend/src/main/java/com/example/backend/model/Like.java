package com.example.backend.model;

public class Like {
}

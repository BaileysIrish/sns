package com.example.backend.service;

public class LikeService {
}

package com.example.backend.repository;

public class CommentRepository {
}

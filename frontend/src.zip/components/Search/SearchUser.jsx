import React from "react";
import { useNavigate } from "react-router-dom";

export default function SearchUser({ user }) {
    const navigate = useNavigate();

    const handleClick = () => {
        navigate(`/profile/${user.email}`);
    };

    return (
        <div className="py-2 cursor-pointer" onClick={handleClick}>
            <div className="flex items-center">
                <img
                    className="w-10 h-10 rounded-full"
                    src={
                        user.profileImage
                            ? `http://localhost:8080${user.profileImage}` // 백엔드 이미지 경로 완성
                            : "/default-image.png" // 기본 이미지
                    }
                    alt={user.nickname}
                />
                <div className="ml-3">
                    <p>{user.nickname}</p>
                    <p className="opacity-70">{user.email}</p>
                </div>
            </div>
        </div>
    );
}

import React, { useState } from "react";
import "./SearchTab.css";
import SearchUser from "./SearchUser";
import axios from "axios";

export default function SearchTab({ open, setOpen }) {
    const [searchValue, setSearchValue] = useState("");
    const [users, setUsers] = useState([]);

    const handleSearch = async (e) => {
        setSearchValue(e.target.value);
        if (e.target.value.trim() === "") {
            setUsers([]);
            return;
        }
        try {
            const response = await axios.get(`http://localhost:8080/api/users/search`, {
                params: { nickname: e.target.value },
            });
            setUsers(response.data);
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };

    return (
        <div className="searchContainer">
            <div className="inputWrapper px-3 pb-5">
                <h1 className="text-2xl font-semibold mb-10 ml-3">검색</h1>
                <input
                    type="text"
                    placeholder="검색"
                    className="searchInput"
                    value={searchValue}
                    onChange={handleSearch}
                />
            </div>
            <hr />
            <div className="px-3">
                {users.map((user) => (
                    <SearchUser key={user.email} user={user} />
                ))}
            </div>
        </div>
    );
}

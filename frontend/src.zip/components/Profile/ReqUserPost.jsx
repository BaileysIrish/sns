import React, { useState, useEffect } from "react";
import ReqUserPostCard from "./ReqUserPostCard";
import { getMyPosts } from "../../api/posts"; // 내가 작성한 게시물 가져오는 API
import { getCurrentUser } from "../../api/User"; // 로그인된 사용자 정보 가져오기

export default function ReqUserPost() {
    const [posts, setPosts] = useState([]); // 내가 작성한 게시물 상태
    const [email, setEmail] = useState(""); // 로그인된 사용자 이메일

    // 현재 로그인된 사용자의 이메일 가져오기
    useEffect(() => {
        const fetchCurrentUser = async () => {
            try {
                const user = await getCurrentUser(); // 현재 사용자 정보 요청
                setEmail(user.email); // 이메일 설정
            } catch (error) {
                console.error("로그인된 사용자 정보를 가져오는 데 실패했습니다:", error);
            }
        };
        fetchCurrentUser();
    }, []);

    // 내가 작성한 게시물 가져오기
    useEffect(() => {
        const fetchMyPosts = async () => {
            if (email) {
                try {
                    const response = await getMyPosts(email); // 내가 작성한 게시물만 요청
                    setPosts(response);
                } catch (error) {
                    console.error("게시물을 가져오는 중 오류 발생:", error);
                }
            }
        };
        fetchMyPosts();
    }, [email]);

    return (
        <div>
            <div className="flex flex-wrap">
                {posts.map((post) => (
                    <ReqUserPostCard key={post.boardNumber} post={post} />
                ))}
            </div>
        </div>
    );
}

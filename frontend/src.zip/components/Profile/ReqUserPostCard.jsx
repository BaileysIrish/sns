import React, { useEffect, useState } from "react";
import { AiFillHeart } from "react-icons/ai";
import { FaComment } from "react-icons/fa";
import { getLikeCount } from "../../api/likes";
import { getCommentsByBoardId } from "../../api/comments";
import "./ReqUserPostCard.css";

export default function ReqUserPostCard({ post }) {
    const [likeCount, setLikeCount] = useState(0);
    const [commentCount, setCommentCount] = useState(0);
    const file = post?.files?.[0];

    useEffect(() => {
        const fetchCounts = async () => {
            if (!post?.boardNumber) {
                console.error("boardNumber가 없습니다.");
                return;
            }
            try {
                console.log("Fetching data for boardNumber:", post.boardNumber);

                const likes = await getLikeCount(post.boardNumber);
                const comments = await getCommentsByBoardId(post.boardNumber);

                console.log("좋아요 수:", likes);
                console.log("댓글 수:", comments.length);

                setLikeCount(likes);
                setCommentCount(comments.length);
            } catch (error) {
                console.error("Error fetching counts:", error.message);
            }
        };

        fetchCounts();
    }, [post.boardNumber]);

    return (
        <div className="p-2 relative">
            <div className="post w-60 h-60 relative group">
                {/* 이미지 또는 비디오 표시 */}
                {file?.fileType.startsWith("image/") ? (
                    <img
                        className="cursor-pointer object-cover w-full h-full"
                        src={file.fileUrl}
                        alt="게시물 이미지"
                    />
                ) : file?.fileType.startsWith("video/") ? (
                    <video
                        className="cursor-pointer object-cover w-full h-full"
                        controls
                    >
                        <source src={file.fileUrl} type={file.fileType} />
                    </video>
                ) : (
                    <div className="flex items-center justify-center w-full h-full bg-gray-200">
                        <span>지원되지 않는 파일 형식</span>
                    </div>
                )}

                {/* 좋아요와 댓글 오버레이 */}
                <div className="overlay absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white">
                    <div className="overlay-text flex space-x-6">
                        <div className="flex items-center">
                            <AiFillHeart className="mr-1" />
                            <span>{likeCount}</span>
                        </div>
                        <div className="flex items-center">
                            <FaComment className="mr-1" />
                            <span>{commentCount}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
